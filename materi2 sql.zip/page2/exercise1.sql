/*
ambil data harga setelah pajak penjualan dari kolom price
dengan melanjutkan statement dibawah
*/

SELECT name, price,
FROM purchases;

SELECT name, price * 1.09